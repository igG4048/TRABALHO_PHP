<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/pag_beleza_pessoal.css">
    <link rel="icon" type="image/png" href="img/farmacia_logo.png">
</head>

<body>
    <header>
        <a href="index.php">
            <img class="farmacia_logo" src="img/FARMAAUREA.png" alt="">
        </a>
    </header>

    <div class="container">
        <h2>Beleza Pessoal</h2>
        <p class="descricao">
            Aqui você encontra produtos de cuidado diário, higiene, estética e bem-estar.
            Escolha o que deseja e aproveite nossas ofertas!
        </p>

        <div class="produtos">

            <div class="produto">
                <img src="img/GELDELIMPEZA-SECAO.jpg" alt="">
                <div class="titulo">Actine Darrow Gel de Limpeza</div>
                <div class="preco">R$ 59,99</div>
                <button class="botao">Adicionar ao carrinho</button>
            </div>


            <div class="produto">
                <img src="img/CETAPHIL-SECAO.jpg" alt="">
                <div class="titulo">Cetaphil Loção Hidratante 500 ml</div>
                <div class="preco">R$ 47,90</div>
                <button class="botao">Adicionar ao carrinho</button>
            </div>

            <div class="produto">
                <img src="img/HIPOGLOS-SECAO.jpg" alt="">
                <div class="titulo">Hipoglós Transparente 120g</div>
                <div class="preco">R$ 78,99</div>
                <button class="botao">Adicionar ao carrinho</button>
            </div>


        </div>
    </div>

</body>

</html>