<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FarmaAuréa - Farmacia de SBC</title>
    <link rel="icon" type="image/png" href="img/farmacia_logo.png">
    <link rel="stylesheet" href="css/Pagina_principal.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@12/swiper-bundle.min.css" />


</head>

<body>

    <div class="container">
        <header>
            <a href="">
                <img class="farmacia_logo" src="img/FARMAAUREA.png" alt="">
            </a>

            <form action="searh">
                <input type="text" placeholder="Buscar Na Farma Auréa" name="" id="">
                <button type="submit"><img class="lupa" src="img/Lupa.png" alt=""></button>

            </form>
            <a href="pag_cadastro.php">
                <div class="login-box">
                    <img src="img/png-transparent-computer-icons-user-login-swiggy-blue-text-computer.png"
                        class="user-icon" alt="">
                    <span>Entrar ou cadastrar</span>

                </div>
            </a>
            <a href="pag_carrinho.php">
                <div class="carrinho">
                    <img src="img/CARRINHO_SEM_fUNDO.png" class="carrinho-icon" alt="">
                    <span>Carrinho de Compras</span>
                </div>
            </a>
        </header>

        <nav>

            <a href="pag_cupom.php">
                <div class="cupom-box">
                    <img src="img/CUPONS.png" class="cupom" alt="">
                    <span>CUPONS E DESCONTOS</span>

                </div>
            </a>

            <a href="pag_beleza_pessoal.php">
                <div class="autoc-box">
                    <img src="img/AC_.png" class="autoc_img" alt="">
                    <span>BELEZA PESSOAL</span>
                </div>
            </a>
            <a href="pag_carrinho.php">
                <div class="entrega-box">
                    <img src="img/entrega-pin.png" class="entrega_img" alt="">
                    <span>ENTREGAS E PEDIDOS</span>
                </div>
            </a>
        </nav>

        <main>
            <div class="produtos-container">
                <h2>Mais comprados</h2>

                <div class="produtos-wrapper">
                    <button class="seta esquerda" onclick="scrollProdutos(-1)">&#10094;</button>

                    <div class="produtos-lista" id="produtosLista">
                        <a href="Pampers_Fraldas92uni_Pag.php">
                            <div class="produto-card">
                                <img src="img/FRALDAS-SECAO.jpg">
                                <h4>Fraldas PAMPERS 92 Uni</h4>
                                <p class="preco">R$ 99,90</p>
                            </div>
                        </a>
                        <a href="Pampers_Fraldas_64uni_Pag.php">
                            <div class="produto-card">
                                <img src="img/FRALDAS64-SECAO.jpg">
                                <h4>Fraldas PAMPERS 64 Uni</h4>
                                <p class="preco">R$ 59,90</p>
                            </div>
                        </a>
                        <a href="Fortalize_produto.php">
                            <div class="produto-card">
                                <img src="img/FOTALIZE-SECAO.jpg">
                                <h4>Eximia Fortalize S Comprimidos</h4>
                                <p class="preco">R$ 399,90</p>
                            </div>
                        </a>
                        <a href="Gel_de_limpeza_pag.php">
                            <div class="produto-card">
                                <img src="img/GELDELIMPEZA-SECAO.jpg">
                                <h4>Actine Darrow Gel de Limpeza</h4>
                                <p class="preco">R$ 59,99</p>
                            </div>
                        </a>
                        <a href="hipogloss_produto_pag.php">
                            <div class="produto-card">
                                <img src="img/HIPOGLOS-SECAO.jpg">
                                <h4>Hipoglós Transparente 120g</h4>
                                <p class="preco">R$ 78,99</p>
                            </div>
                        </a>
                        <a href="cremeassaduras_produto_pag.php">
                            <div class="produto-card">
                                <img src="img//CREMEASSSADURAS-SECAO.jpg">
                                <h4>Creme Preventivo de Assaduras Needs</h4>
                                <p class="preco">R$ 42,90</p>
                            </div>
                        </a>
                        <a href="protetor_solar_produto.php">
                            <div class="produto-card">
                                <img src="img/protetor_solar.png">
                                <h4>Solar Protect & Hidrata FPS50 400ml</h4>
                                <p class="preco">R$ 19,90</p>
                            </div>
                        </a>
                        <a href="cremeassaduras_produto_pag.php">
                            <div class="produto-card">
                                <img src="img/CETAPHIL-SECAO.jpg">
                                <h4>Cetaphil Loção Hidratante 500 ml</h4>
                                <p class="preco">R$ 47,90</p>
                            </div>
                        </a>
                        <a href="tadalafila_produto_pag.php">
                            <div class="produto-card">
                                <img src="img/tadala.png">
                                <h4>TADALAFILA 20g</h4>
                                <p class="preco">R$ 47,90</p>
                            </div>
                        </a>

                    </div>

                    <button class="seta direita" onclick="scrollProdutos(1)">&#10095;</button>
                </div>
            </div>


            <div class="carousel-section">
                <h2>🔥🔥 Descontos Da Semana! 🔥🔥</h2>

                <div class="carousel-container">
                    <button class="prev">❮</button>

                    <div class="carousel">

                        <a href="cremeassaduras_produto_pag.php">
                            <div class="item">
                                <h1>-18,90%</h1>
                                <img src="img/CREMEASSSADURAS-SECAO.jpg" alt="Produto 1">
                                <h3>Creme Preventivo de Assaduras Needs</h3>
                                <h5>R$ 52,90</h5>
                                <p>R$ 42,90</p>
                            </div>
                        </a>
                        <a href="Fortalize_produto.php">

                            <div class="item">
                                <h1>-25,01%</h1>
                                <img src="img/FOTALIZE-SECAO.jpg" alt="Produto 2">

                                <h3>Eximia Fortalize S Comprimidos</h3>
                                <h5>R$ 399,90</h5>
                                <p>R$ 299,90</p>
                            </div>
                        </a>

                        <a href="hipogloss_produto_pag.php">
                            <div class="item">
                                <h1>-10,01%</h1>
                                <img src="img/HIPOGLOS-SECAO.jpg" alt="Produto 3">

                                <h3>Hipoglós Transparente 120g</h3>
                                <h5>R$ 78,99</h5>
                                <p>R$ 68,99</p>
                            </div>
                        </a>
                        <a href="Pampers_Fraldas92uni_Pag.php">

                            <div class="item">
                                <h1>-16,69%</h1>
                                <img src="img/FRALDAS-SECAO.jpg" alt="Produto 4">

                                <h3>Fraldas PAMPERS 92 Uni</h3>
                                <h5>R$ 99,90</h5>
                                <p>R$ 89,90</p>
                            </div>
                        </a>

                        <a href="bepantol_produto_pag.php">
                            <div class="item">
                                <h1>-20,88%</h1>
                                <img src="img/LOCAOFACIAL-SECAO.jpg" alt="Produto 5">
                                <h3>Bepantol Derma Loção Facial Noturna 50Ml</h3>
                                <h5>R$ 60,75</h5>
                                <p>R$ 50,75</p>
                            </div>
                        </a>
                        <a href="Pampers_Fraldas_64uni_Pag.php">
                            <div class="item">
                                <h1>16,69%</h1>
                                <img src="img/FRALDAS64-SECAO.jpg" alt="Produto 5">
                                <h3>Fraldas PAMPERS 64 Uni</h3>
                                <h5>R$ 59,90</h5>
                                <p>R$ 49,90</p>
                            </div>
                        </a>
                        <a href="cetaphil_produto_pag.php">
                            <div class="item">
                                <h1>20,88%</h1>
                                <img src="img/CETAPHIL-SECAO.jpg" alt="Produto 5">
                                <h3>Cetaphil Loção Hidratante 500 ml</h3>
                                <h5>R$ 47,90</h5>
                                <p>R$ 37,90</p>
                            </div>
                        </a>
                        <a href="Gel_de_limpeza_pag.php">
                            <div class="item">
                                <h1>16,67%</h1>
                                <img src="img/GELDELIMPEZA-SECAO.jpg" alt="Produto 5">
                                <h3>Actine Darrow Gel de Limpeza</h3>
                                <h5>R$ 59,99</h5>
                                <p>R$ 49,99</p>
                            </div>
                        </a>


                    </div>

                    <button class="next">❯</button>
                </div>
            </div>

            <div class="container-cuponsetc"></div>
            <h2 class="sla">Alguns Dos Nossos Cupons De Descontos</h2>
            <span>
                Descubra maneiras simples e inteligentes de economizar em suas compras do dia a dia. Aqui você encontra
                cupons exclusivos, ofertas especiais e oportunidades
                únicas para pagar menos sem abrir mão da qualidade. Aproveite nossas dicas e veja como é fácil
                transformar pequenos descontos em grandes economias!
            </span>
            <a href="pag_cupom.php"><img src="img/CUPOESZINHO.png" class="desconto-img" alt="">
            </a>

        </main>
        <footer>

            <div class="contato"><a href="">
                    <img src="img/contato-logo.png" alt="">
                    <h3>Central De Atendimento </h3>
                    <h4>Caso Tenha Algum Problema Nos Informe ~
                        11-9999-9999 ~
                    </h4>
            </div>
            </a>

            <div class="redes-sociais">
                <h3>Nossas Redes</h3>
                <a href="">
                    <img src="img/facebook-logo.png" alt="">
                </a>
                <a href="">
                    <img src="img/instagram-logo.png" alt="">
                </a>
                <a href="">
                    <img class="twitter-logo" src="img/twitter-logo.png" alt="">
                </a>
            </div>
        </footer>
    </div>
    <script>
        function scrollProdutos(direcao) {
            const lista = document.getElementById("produtosLista");
            const cardWidth = 220;

            lista.scrollLeft += direcao * cardWidth;
        }
    </script>
    <script>
        const carousels = document.querySelectorAll(".carousel-container");

        carousels.forEach(container => {
            const carousel = container.querySelector(".carousel");
            const prev = container.querySelector(".prev");
            const next = container.querySelector(".next");

            next.addEventListener("click", () => {
                carousel.scrollLeft += 250;
            });

            prev.addEventListener("click", () => {
                carousel.scrollLeft -= 250;
            });
        });
    </script>
</body>

</html>