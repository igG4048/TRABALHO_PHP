<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/pag_cupom.css">
    <link rel="icon" type="image/png" href="img/farmacia_logo.png">
</head>

<body>
    <header>
        <a href="index.php">
            <img class="farmacia_logo" src="img/FARMAAUREA.png" alt="">
        </a>
    </header>
    <h1>Cupons de Desconto </h1>


    <div class="cupom">
        <p>10% de desconto:</p>
        <p class="codigo">TESTE10</p>
    </div>


    <div class="cupom">
        <p>Frete grátis:</p>
        <p class="codigo">FRETEGRATIS</p>
    </div>


    <div class="cupom">
        <p>R$20 de desconto:</p>
        <p class="codigo">DESCONTO20</p>
    </div>

    <div class="cupom">
        <p>R$20 de desconto:</p>
        <p class="codigo">DESCONTO20</p>
    </div>
    <div class="cupom">
        <p>Frete grátis:</p>
        <p class="codigo">FRETEGRATIS</p>
    </div>
    <div class="cupom">
        <p>10% de desconto:</p>
        <p class="codigo">TESTE10</p>
    </div>
    <div class="cupom">
        <p>10% de desconto:</p>
        <p class="codigo">TESTE10</p>
    </div>


    <div class="cupom">
        <p>Frete grátis:</p>
        <p class="codigo">FRETEGRATIS</p>
    </div>


    <div class="cupom">
        <p>R$20 de desconto:</p>
        <p class="codigo">DESCONTO20</p>
    </div>

    <div class="cupom">
        <p>R$20 de desconto:</p>
        <p class="codigo">DESCONTO20</p>
    </div>
    <div class="cupom">
        <p>Frete grátis:</p>
        <p class="codigo">FRETEGRATIS</p>
    </div>
    <div class="cupom">
        <p>10% de desconto:</p>
        <p class="codigo">TESTE10</p>
    </div>


</body>

</html>