<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/tadalafila.css">
    <link rel="icon" type="image/png" href="img/farmacia_logo.png">
</head>

<body>
    <a href="index.php">
        <img class="logo-farma" src="img/FARMAAUREA.png" alt="">
    </a>

    <div class="product-container">
        <div class="coluna-imagem">
            <div class="imagem-placeholder">
                <img src="img/tadala.png" alt="">
            </div>
        </div>

        <div class="coluna-detalhes">

            <div class="free-shipping-tag">Frete Grátis: [SBC]</div>

            <div class="avaliacao-vazia">
                <span class="estrelas">⭐⭐⭐⭐☆</span>
                <span class="reviews">(4 avaliações)</span>
            </div>

            <h1 class="titulo-produto">[TADALAFILA 20g]</h1>

            <p class="produto-disponivel">PRODUTO DISPONÍVEL (99UNI)</p>

            <p class="marca">Marca: [BIOPHARMA]</p>

            <hr class="separador">

            <div class="secao-oferta">
                <div class="caixa-tempo">
                    <p class="caixa-titulo">TEMPO RESTANTE</p>
                    <div class="timer">
                        <span class="timer-unidade">00</span>
                        <span class="timer-unidade">00</span>
                        <span class="timer-unidade">00</span>
                    </div>
                    <p class="timer-label">dias min seg</p>
                </div>

                <div class="caixa-desconto">
                    <p class="caixa-titulo">[TIPO DA OFERTA]</p>
                    <div class="desconto-valores">
                        <span class="desconto-porcentagem">00%</span>
                        <span class="desconto-estoque">00</span>
                    </div>
                    <p class="desconto-label">Desconto Disponíveis</p>
                </div>
            </div>

            <hr class="separador">

            <div class="secao-preco">


                <div class="preco-destaque">
                    <div class="preco-avista">
                        <span class="valor-atual">R$ [47,90]</span>
                        <p class="pagamento-extra">à vista <br> no PIX com 00% desconto</p>
                    </div>

                    <div class="preco-parcelado">
                        <span class="valor-parcelado">R$ [57,90]</span>
                        <p class="pagamento-extra">em até 12x de R$ [4,80] <br> **sem juros** no cartão</p>
                    </div>
                </div>
            </div>

            <button class="botao-comprar">
                COMPRAR <br> COLOCAR NO CARRINHO
            </button>

        </div>
    </div>
</body>

</html>