<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/pag_carrinho.css">
    <link rel="icon" type="image/png" href="img/farmacia_logo.png">
</head>

<body>
    <header>
        <a href="index.php">
            <img class="farmacia_logo" src="img/FARMAAUREA.png" alt="">
        </a>
    </header>

    <div class="carrinho_container">
        <h2> Seu Carrinho de Compras</h2>


        <div class="item">
            <img src="img/tadala.png" alt="">
            <div class="infos">
                <h3>TADALAFILA</h3>
                <p>Tadalafila 20g</p>
                <span class="remover">Remover</span>
            </div>
            <div class="preco">R$ 29,90</div>
        </div>


        <div class="item">
            <img src="https://via.placeholder.com/70" alt="">
            <div class="infos">
                <h3>Produto Teste</h3>
                <p>Descrição curta</p>
                <span class="remover">Remover</span>
            </div>
            <div class="preco">R$ 19,90</div>
        </div>

        <div class="total">
            Total: R$ 49,80
        </div>

        <button class="finalizar">Finalizar Compra</button>

    </div>

</body>

</html>