<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/pag_login.css">
</head>
<body>
     <header>
        <a href="index.php">
        <img class="logo-farma" src="img/FARMAAUREA.png" alt="">
    </a>
     </header>

      <div class="container-login">
        <div class="card-login">

            <h2>Entrar na FarmaAuréa</h2>
            <p class="subtitulo">Acesse sua conta para continuar suas compras</p>

            <form id="formLogin">

                <label for="emailLogin">E-mail:</label>
                <input type="email" id="emailLogin" placeholder="seu.email@exemplo.com" required>

                <label for="senhaLogin">Senha:</label>
                <input type="password" id="senhaLogin" placeholder="Digite sua senha" required>

                <button type="submit" class="btn-login">Entrar</button>

                <p class="link">Ainda não tem conta? <a href="pag_cadastro.php">Criar conta</a></p>
            </form>
 <script>
        document.getElementById("formLogin").addEventListener("submit", function(e){
            e.preventDefault();

            const emailDigitado = document.getElementById("emailLogin").value;
            const senhaDigitada = document.getElementById("senhaLogin").value;

            const emailSalvo = localStorage.getItem("email");
            const senhaSalva = localStorage.getItem("senha");

            if(emailDigitado === emailSalvo && senhaDigitada === senhaSalva){
                alert("Login realizado com sucesso!");
                // redireciona para página protegida
                window.location.href = "home.html";
            } else {
                alert("Email ou senha incorretos.");
            }
        });
    </script>
</body>
</html>