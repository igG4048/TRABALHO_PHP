<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FarmaAuréa</title>
    <link rel="stylesheet" href="css/pag_cadastro.css">
    <link rel="icon" type="image/png" href="img/farmacia_logo.png">
</head>

<body>

    <header class="header-container">
        <div class="header-content">
            <div class="logo-busca">
                <a href="index.php">
                    <img src="img/FARMAAUREA.png" alt="FarmaAurea Logo" class="logo">
                </a>
                <div class="search-bar">
                    <input type="text" placeholder="Buscar Na Farma Auréa">
                    <button>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="25" height="25"
                            fill="#555">
                            <path
                                d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.1-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z" />
                        </svg>
                    </button>
                </div>
            </div>
            <div class="user-cart">
                <div class="user-profile">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="24" height="24" fill="#007bff">
                        <path
                            d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z" />
                    </svg>
                    <span>Entrar ou cadastrar</span>
                </div>
                <div class="cart">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" width="24" height="24" fill="#555">
                        <path
                            d="M0 24C0 10.7 10.7 0 24 0H69.5c22 0 41.5 12.8 50.6 32h411c26.3 0 45.5 25 38.6 50.4l-41 152.3c-8.5 31.4-37 53.3-69.5 53.3H170.7l5.4 28.5c2.2 11.3 12.1 19.5 23.6 19.5H488c13.3 0 24 10.7 24 24s-10.7 24-24 24H200.4c-34.1 0-65.3-17.2-84.6-46.6L35.4 45.3C28.4 31.8 13.3 24 0 24zM160 448a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm336-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z" />
                    </svg>
                    <span>Carrinho de Compras</span>
                </div>
            </div>
        </div>
    </header>


    <main class="main-content">
        <div class="cadastro-section">
            <h2>Crie sua conta na FarmaAuréa</h2>
            <p class="cadastro-subtitle">É rápido e fácil. Preencha os campos abaixo para começar a aproveitar nossas
                ofertas!</p>

            <form class="cadastro-form">
                <div class="form-group">
                    <label for="nome">Nome Completo:</label>
                    <input type="text" id="nome" name="nome" placeholder="Seu nome completo" required>
                </div>

                <div class="form-group">
                    <label for="email">E-mail:</label>
                    <input type="email" id="email" name="email" placeholder="seu.email@exemplo.com" required>
                </div>

                <div class="form-group">
                    <label for="cpf">CPF:</label>
                    <input type="text" id="cpf" name="cpf" placeholder="000.000.000-00" required>
                </div>

                <div class="form-group">
                    <label for="telefone">Telefone:</label>
                    <input type="tel" id="telefone" name="telefone" placeholder="(XX) XXXXX-XXXX">
                </div>

                <div class="form-group">
                    <label for="senha">Senha:</label>
                    <input type="password" id="senha" name="senha" placeholder="Crie uma senha " required>
                </div>

                <div class="form-group">
                    <label for="confirmar-senha">Confirmar Senha:</label>
                    <input type="password" id="confirmar-senha" name="confirmar-senha" placeholder="Repita sua senha"
                        required>
                </div>

                <div class="form-check">
                    <input type="checkbox" id="termos" name="termos" required>
                    <label for="termos">Eu li e concordo com os <a href="#">Termos de Uso</a> e <a href="#">Política de
                            Privacidade</a>.</label>
                </div>

                <button type="submit" class="btn-cadastrar">CADASTRAR</button>
            </form>

            <div class="login-link">
                Já tem uma conta? <a href="pag_login.php">Faça login aqui.</a>
            </div>
        </div>
    </main>
</body>

</html>